#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <ctype.h>

#define MAX_CONNECT_USERS 10
#define USER_INFO_SIZE 3
#define MAX_PIPES 5
char* user_name_str = "Please enter your user name in the command line.\n";
char* password_str = "Please enter your password.\n";
char* connection_close = "Connection closing immediately, please connect again.\n";
char* welcome_login = "\nYou have logined the XO Chess Server.\n\nThere are 4 command you can opearate :\n\n1. Enter '-L' to show all online users.\n2. Enter '-S' to show all online users you can play with and the invite one for the game.\n3. Enter '-Q' anytime you want to log out.\n\n4. Enter '-R' check is there new invitation from another user.\n\n";
char *loop_msg1 = "You are okay to enter command :\n";
char* logout_msg = "You have logout. If you want to login, please connect the server again.\n";
char* rejection_msg = "Your invitation has been rejected.\n";
char* win_msg = "Congratulation, You have Win the game!\n";
char* lose_msg = "You Lose.\n";
char *start_game = "Start The Game";
char *accept_msg = "Opponent Accepted.\n";
char *refused_msg = "Opponent refused";
char* select_msg = "It's your round to make the move. Please enter '1' to '9' toselect the corresponding position.\n\n";
int connected_users = 0;
int online_users = 0;
int pipe_fd[MAX_CONNECT_USERS/2][2];
int used_pipe_nums = 0;

int is_pipe_nums_changed = 0;
struct pipe{
  int fd[2];
  int status;  // 2 is used, 1 is only one thread taken, 0 is idle.
  int thread0_sock;  // -1 means no thread taken.
  int thread1_sock;
};

struct pipe pipe_pool[MAX_PIPES];

void InitPipePool() {
  int i;
  for (i=0; i<MAX_PIPES; i++) {
    pipe(pipe_pool[i].fd);
    pipe_pool[i].status = 0;
    pipe_pool[i].thread0_sock = -1;
    pipe_pool[i].thread1_sock = -1;
  }
}

struct XO_Chess {
  char xo_table[3][3];  // O for O, X for X, ' ' for empty.
  int X_player_sock;
  int O_player_sock;
};

struct XO_Chess the_game[2];

void InitXoChess() {
  int i, j, k;
  for (i=0; i<2; i++) {
    for (j=0; j<3; j++) {
      for (k=0; k<3; k++)
        the_game[i].xo_table[j][k] = ' ';
    }
  }
}

// input only 1 - 9
// chess type are O, X
void SetChessMap(int n, char chess_type, struct XO_Chess* game1) {
  
  switch ( n ) {
    case 1 :  game1->xo_table[0][0] = chess_type; 
             break;
    case 2 :  game1->xo_table[0][1] = chess_type; 
             break;
    case 3 :  game1->xo_table[0][2] = chess_type; 
             break;
    case 4 :  game1->xo_table[1][0] = chess_type; 
             break;
    case 5 :  game1->xo_table[1][1] = chess_type; 
             break;
    case 6 :  game1->xo_table[1][2] = chess_type; 
             break;
    case 7 :  game1->xo_table[2][0] = chess_type; 
             break;
    case 8 :  game1->xo_table[2][1] = chess_type; 
             break;
    case 9 :  game1->xo_table[2][2] = chess_type; 
             break;
  }
  
}

int DetectWinner(int your_sockfd, int opponent_sockfd, char table[3][3]) {
  char winner = ' ';

  // check horisontal 
  int i, j;
    for (i=0; i<3; i++) 
        if ( table[i][0] == table[i][1] && table[i][1] == table[i][2] ) {
          winner = table[i][0];
          break;
        }

    // check the stragiht line
    for (i=0; i<3; i++)  
        if ( table[0][i] == table[1][i] && table[1][i] == table[2][i] ) {
          winner = table[0][i];
          break;
        }

    // check the '\' line
    if ( table[0][0] == table[1][1] && table[1][1] == table[2][2] ) 
          winner = table[0][0];

    // check the '/' line
    if ( table[0][2] == table[1][1] && table[1][1] == table[2][0] ) 
          winner = table[0][2];
      
  if (winner==' ')
    return 0;
  if (winner=='O') 
    return 1;
  if (winner=='X') 
    return -1;
}

void Sendtutorial(int your_sockfd, int opponent_sockfd) {
  int i, j;
  char send_buf[200];
  sprintf(send_buf, "You can enter '1' - '9' to select the box you want your next chess takes place in following XO chess map.\n\n"); 
  sprintf(send_buf + strlen(send_buf), "   ----------\n"); 
  sprintf(send_buf + strlen(send_buf), "   1 | 2 | 3\n"); 
  sprintf(send_buf + strlen(send_buf), "   4 | 5 | 6\n"); 
  sprintf(send_buf + strlen(send_buf), "   7 | 8 | 9\n"); 
  sprintf(send_buf + strlen(send_buf), "   ----------\n\n"); 
  send(your_sockfd, send_buf, strlen(send_buf), 0);
  send(opponent_sockfd, send_buf, strlen(send_buf), 0);
}

void SendPrintXO(int your_sockfd, int opponent_sockfd, char table[3][3]) {
  int i, j;
  char send_buf[200];
      sprintf(send_buf + strlen(send_buf), "   ----------\n"); 
  for (i=0; i<3; i++) {
    sprintf(send_buf + strlen(send_buf), "   %c | %c | %c\n", table[i][0], table[i][1], table[i][2]); 
    if (i!=2)
      sprintf(send_buf + strlen(send_buf), "   ----------\n"); 
  }
  send(your_sockfd, send_buf, strlen(send_buf), 0);
  send(opponent_sockfd, send_buf, strlen(send_buf), 0);
}

struct UserInfo {
  char name[100];
  char password[100];
};

struct UserInfo user_info[USER_INFO_SIZE];


struct LoginedUser {
  char name[100];
  int sockfd;
  int is_in_game;
  int is_online;
};
struct LoginedUser online_user[USER_INFO_SIZE];

void UserLogout(int correspond_index) {
  int i;
  for (i=correspond_index; i<USER_INFO_SIZE-1; i++)
    online_user[i] = online_user[i+1]; 
  online_users--;
}

void PrintOnlineUsers(int sockfd) {
  char send_buf[4096];
  sprintf(send_buf, "\nUsers are Online :\n id     user name\n");
  int online_nums = online_users;
  int i;
  for (i=0; i<online_nums; i++) {
    sprintf(send_buf + strlen(send_buf), " %d       %s\n", i+1, online_user[i].name);
  } 
  sprintf(send_buf + strlen(send_buf), "------------------------------------------\n\n");
  send(sockfd, send_buf, strlen(send_buf), 0);
}

void PrintCompetitor(int sockfd) {
  char send_buf[4096];
  sprintf(send_buf, "Enter the id of the user who you want to invite.\nUsers are Online :\n id     user name\n");
  int online_nums = online_users;
  int i;
  for (i=0; i<online_nums; i++) {
    sprintf(send_buf + strlen(send_buf), "  %d     %s", i+1, online_user[i].name);
    if ( online_user[i].is_in_game == 0)
      sprintf(send_buf + strlen(send_buf), "   idle\n");
    else if ( online_user[i].is_in_game == 1)
      sprintf(send_buf + strlen(send_buf), "   Playing\n");
    
  } 
  sprintf(send_buf + strlen(send_buf), "You can only select the user who is in idle.\n");
  sprintf(send_buf + strlen(send_buf), "------------------------------------------\n\n");
  send(sockfd, send_buf, strlen(send_buf), 0);
}

void* send_pipe_msg(int write_end, char* send_buf) {
  send(write_end, send_buf, sizeof(send_buf), 0);
  
}

void* login_handler(void* socket_fd) {
  char recv_buf[4096];
  int recv_len;
  char send_buf[4096];

  // Ask User Name.
  int sockfd = *(int*)socket_fd;
  send(sockfd, user_name_str, strlen(user_name_str), 0);
  recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
  if (recv_len < 0) {
    send(sockfd, connection_close, strlen(user_name_str), 0);
    close(sockfd);
    return 0;
  }
  // Check the user.
  int account_exsited = 0;
  int correspond_user;
  int i;
  for (i=0; i<USER_INFO_SIZE; i++) {
    if ( strncmp(user_info[i].name, recv_buf, strlen(user_info[i].name)) == 0 ){ 
      account_exsited = 1;
      correspond_user = i;
      break;
    }
      
  }
  // Ask User Password.
  if (account_exsited) {
    memset(recv_buf, 0, 4096);  // clear the recv buffer.
    send(sockfd, password_str, strlen(password_str), 0);
    recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);

    // Check the password.
    if ( strncmp(user_info[correspond_user].password, recv_buf, strlen(user_info[correspond_user].password) ) == 0 ) {
    memset(recv_buf, 0, 4096);  // clear the recv buffer.
    send(sockfd, welcome_login, strlen(welcome_login), 0);

    } else {  // Wrong Password, goint to shutdown the socket.
      send(sockfd, connection_close, strlen(connection_close), 0);
      close(sockfd);
      return 0;
    }

  } else {
    // shutdown this socket, send the close message to client.
    send(sockfd, connection_close, strlen(connection_close), 0);
    close(sockfd);
    return 0;
  }

  // User have logged in.
  int online_index = online_users;
  strcpy(online_user[online_index].name, user_info[correspond_user].name);
  online_user[online_index].sockfd = sockfd;
  online_user[online_index].is_in_game = 0;
  online_user[online_index].is_online = 1;
  online_users++;
  int current_user_index = online_index;
  printf("\nuser's sockfd = %d\n\n", sockfd);

  // Enter the loop which detecting the command.
  while (1) {
    send(sockfd, loop_msg1, strlen(loop_msg1), 0);
    recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
    char operand = recv_buf[1];
    memset(recv_buf, 0, 4096);  // clear the recv buffer.
   
    int selected_user_index;
    char pipe_recv_buf[100];
    char game_recv_buf[10];
    int n_read = 0;
    int current_pipe = 0;
    int chess_action = 0;
    switch ( operand ) {
      case 'R' : // Recived invite massage.
                 break;
      
      case 'Y' : // Accept invitation from other online user.
                 // find an idle pipe from pipe pool.
                 //for (i=0; i<MAX_PIPES; i++) {  // always assume pool has idle
                 //  if (pipe_pool[i].status==0) {
                 //    current_pipe = i;
                 //  }
                 //}
                 memset(recv_buf, 0 , sizeof(recv_buf));
                 current_pipe = 0;
                 write(pipe_pool[current_pipe].fd[1], start_game, strlen(start_game));
                 Sendtutorial(pipe_pool[current_pipe].thread0_sock, pipe_pool[current_pipe].thread1_sock);
                 printf("tutorial sent.\n");
                 the_game[0].O_player_sock = sockfd;
                 the_game[0].X_player_sock = pipe_pool[current_pipe].thread1_sock;
                 memset(game_recv_buf, 0 , sizeof(game_recv_buf));
                   while (1) {
                     // new round

                     if (DetectWinner(sockfd, pipe_pool[current_pipe].thread1_sock, the_game[0].xo_table)!=0) {
                       int winner = DetectWinner(sockfd, pipe_pool[current_pipe].thread1_sock, the_game[0].xo_table);
                       break;
                     }
                     printf("monitoring pipe[0]\n ");

                     // wait pipe msg arrived.
                     while ( (n_read = read(pipe_pool[current_pipe].fd[0], pipe_recv_buf, 100)) <= 0 ) {  // No message from pipe yet.
                       sleep(1);
                     }
                     printf("pipe read end fd : %d,  write end fd : %d\n", pipe_pool[current_pipe].fd[0], pipe_pool[current_pipe].fd[1]);
                     printf("pipe thread0 fd : %d,  pipe thread1 fd : %d\n", pipe_pool[current_pipe].thread0_sock, pipe_pool[current_pipe].thread1_sock);
                     if (strstr(pipe_recv_buf, "X player have selected")!=NULL)
                       printf("%s\n", pipe_recv_buf); 
                     n_read = 0;
                     memset(pipe_recv_buf, 0, 100);  // clear the recv buffer.
                     //this round  O player can select.

                     send(the_game[0].O_player_sock, select_msg, strlen(select_msg), 0);
                     // wait user send the msg of the chess action
                     recv(the_game[0].O_player_sock, game_recv_buf, 10, 0);
                     chess_action = atoi(game_recv_buf);          
                     SetChessMap(chess_action, 'O', the_game);
                     SendPrintXO(the_game[0].O_player_sock, the_game[0].X_player_sock, the_game[0].xo_table);
                     memset(game_recv_buf, 0, 10); // clear the buffer.
                     write(pipe_pool[current_pipe].fd[1], "O player have selected", 21);
                   }
                 break;
      case 'N' : // Refuse invitation and send the refuse message.
              
                break;
                 
                 
      case 'Q' : UserLogout(online_index) ;
                 send(sockfd, logout_msg, strlen(logout_msg), 0);
                 printf("user %s have logout.\n", online_user[current_user_index].name);
                 close(sockfd);
                 return 0;
                
      case 'L' : PrintOnlineUsers(sockfd);
                 break;

      case 'S' : PrintCompetitor(sockfd);
                 recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
                 printf("in case 'S' : %s\n", recv_buf);
           if (recv_buf[strlen(recv_buf)-1]=='\n')
             recv_buf[strlen(recv_buf)-1] = '\n';
           
           if ( !atoi(recv_buf)) {  // Wrong entered id                  
           memset(recv_buf, 0, 4096);  // clear the recv buffer.
           continue;  // go back to loop.
           } 

           selected_user_index = atoi(recv_buf)-1;
           printf("selected user id : %d\n", selected_user_index);
           // send request to the selected user.
           int selected_user_sock = online_user[selected_user_index].sockfd;
           printf("\nselected user's sockfd = %d\n", selected_user_sock);
           sprintf(send_buf, "!!User %s invite you for a game. If you accept it plase enter '-Y', otherwise enter '-N'\n\n", online_user[current_user_index].name);
           send(selected_user_sock, send_buf, strlen(send_buf), 0);
           memset(send_buf, 0, 4096);  // clear the recv buffer.
           printf("invite has sent.\n");
           //for (i=0; i<MAX_PIPES; i++) {
           //  if (pipe_pool[i].status == 1)  // pipe is taken only by one
           //    if (pipe_pool[i].thread0_sock==selected_user_sock) {
           //      current_pipe = i;
           //      break;
           //    }
           //}
           current_pipe = 0;
           pipe_pool[current_pipe].status = 2;
           pipe_pool[current_pipe].thread0_sock = selected_user_sock;
           pipe_pool[current_pipe].thread1_sock = sockfd;
           printf("a pipe is settled.\n");
           // pipe taken
           printf("start reading pipe read end.\n");
           int n_read = 0;
           while ( (n_read = read(pipe_pool[current_pipe].fd[0], pipe_recv_buf, 100)) <= 0 ) {  // No message from pipe yet.
             printf("pipe[0] no data yet.\n");
             sleep(1);
           }

           n_read = 0;
           printf("in -S try to read pipe.\n");
           //if ( strstr(pipe_recv_buf, "Start The Game")!=NULL ) {
           //  printf("pipe has read the data :%s\n\n", pipe_recv_buf); 
           //  memset(pipe_recv_buf, 0, 100);  // clear the recv buffer.
           //  send(sockfd, accept_msg, strlen(accept_msg), 0);
           //} else {  // Opponent refused.
           //  memset(pipe_recv_buf, 0, 100);  // clear the recv buffer.
           //  send(sockfd, refused_msg, strlen(refused_msg), 0);       
           //  break;
          // }
           
           printf("in -S finished read pipe.\n");

           char game_recv_buf[10];
                 while (1) {
                     // new round

                   if (DetectWinner(sockfd, pipe_pool[current_pipe].thread1_sock, the_game[0].xo_table)!=0) {
                     int winner = DetectWinner(sockfd, pipe_pool[current_pipe].thread1_sock, the_game[0].xo_table);
                     break;
                   }

                   // wait pipe msg arrived.
                   while ( (n_read = read(pipe_pool[current_pipe].fd[0], pipe_recv_buf, 100)) <= 0 ) {  // No message from pipe yet.
                     sleep(1);
                   }
                   if (strstr(pipe_recv_buf, "O player have selected")!=NULL)
                     printf("%s\n", pipe_recv_buf); 
                   n_read = 0;
                   memset(pipe_recv_buf, 0, 100);  // clear the recv buffer.
                   //this round  X player can select.

                   send(the_game[0].X_player_sock, select_msg, strlen(select_msg), 0);
                   // wait user send the msg of the chess action
                   recv(the_game[0].X_player_sock, game_recv_buf, 10, 0);
                   chess_action = atoi(game_recv_buf);          
                   SetChessMap(chess_action, 'X', the_game);
                   SendPrintXO(the_game[0].O_player_sock, the_game[0].X_player_sock, the_game[0].xo_table);
                   memset(game_recv_buf, 0, 10); // clear the buffer.
                   write(pipe_pool[current_pipe].fd[1], "X player have selected", 21);
                 }
                 break;

           default : continue;
        }

        // No correct command, go to next loop.
        memset(recv_buf, 0, 4096);  // clear the recv buffer.
  }
}

int main() {

  // seting user info.
  strcpy(user_info[0].name, "guest1");
  strcpy(user_info[0].password, "guest1");
  strcpy(user_info[1].name, "guest2");
  strcpy(user_info[1].password, "guest2");
  strcpy(user_info[2].name, "guest3");
  strcpy(user_info[2].password, "guest3");
  
  InitPipePool();
  InitXoChess();
  int listenfd, socketfd, pid;
  int fd;
  static struct sockaddr_in serv_addr;
  static struct sockaddr_in client_addr;
  char read_buf[4096], write_buf[200000];
  FILE *fp;
  
  listenfd = socket(AF_INET, SOCK_STREAM, 0);
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(8080);
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(struct sockaddr_in));
  if (listen(listenfd, 4)==-1) {
    printf("listen failed.");
    exit(0);
  }
  int len;

    printf("listening.\n");
    //socketfd = accept(listenfd, (struct sockaddr*)&client_addr, &len);
    //printf("A socket connected.\n");


  pthread_t connected_user[MAX_CONNECT_USERS];
  while (1) {
    socketfd = accept(listenfd, (struct sockaddr*)&client_addr, &len);
    connected_users++;
    if ( pthread_create(&connected_user[connected_users], NULL, login_handler, (void*)&socketfd) < 0)
      printf("Thread creation error.\n");
  }
  return 0;
}
