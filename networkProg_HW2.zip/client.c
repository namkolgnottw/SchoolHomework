#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

int main(int argc) {

  int sockfd;
  static struct sockaddr_in serv_addr;
  char request1[1024];
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(8080);
  inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr.s_addr);

  sockfd = socket( AF_INET, SOCK_STREAM, 0);
  if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(struct sockaddr_in))==-1) {
       printf("connection failed.\n");
       exit(0);
     } else {
        printf("connect established.\n");
     }
  int recv_len;
  char recv_buf[4096];
  memset(recv_buf, 0, sizeof(recv_buf));

  // Recieve user name request.
  recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
  //if (strstr(recv_buf, "Please enter your user name")==NULL) {
  //  close(sockfd);  // Not recieve the correct message.
  //  return 0;         // shut down.
  //}
  printf("client test: after recieved.\n");
  printf("%s", recv_buf);
  memset(recv_buf, 0, sizeof(recv_buf));

  // Recieved login message
  char user_name[100];
  fgets(user_name, 100, stdin);
  if (user_name[strlen(user_name)-1]=='\n')
    user_name[strlen(user_name)-1]=='\0';
  send(sockfd, user_name, strlen(user_name), 0);

  // Recieved password required message.
  recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
 // if (strstr(recv_buf, "Please Enter your password")==NULL) {
 //   close(sockfd);  // Not recieve the correct message.
 //   return 0;         // shut down.
 //}
  printf("%s", recv_buf);
  memset(recv_buf, 0, sizeof(recv_buf));

  // Enter password
  char password[100];
  fgets(password, 100, stdin);
  if (password[strlen(password)-1]=='\n')
    password[strlen(password)-1]=='\0';
  send(sockfd, password, strlen(password), 0);


  // Successful login
  // Enter the loop 
  char send_buf[1024];
  while (1) {
    recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
      printf("%s", recv_buf);
    if (strstr(recv_buf, "You are okay to enter command")!=NULL ) {
      fgets(send_buf, 1024, stdin);
      send(sockfd, send_buf, strlen(send_buf), 0);
        
    } else if ( strstr(recv_buf, "!!")!=NULL ) {
        fgets(send_buf, 1024, stdin);
        send(sockfd, send_buf, strlen(send_buf), 0);

        // Entered 'Y'
        if ( strstr(send_buf, "-Y")!=NULL ) {
          memset(send_buf, 0, sizeof(send_buf));
          memset(recv_buf, 0, sizeof(recv_buf));
          printf("waiting for the tutorial.\n");
          // Accept the tutorial
          recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
          printf("%s", recv_buf);
          memset(recv_buf, 0, sizeof(recv_buf));

        printf("\nGame Start !\n\n");
        while (1) {
        
         // Enter the game
         recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
         printf("%s", recv_buf);
         if ( strstr(recv_buf, "You Lose" )!=NULL || strstr(recv_buf, "You have Win")!=0)   {  
            printf("\nGame is finished.\n\n");
            break;
          }
        memset(recv_buf, 0, sizeof(recv_buf));
        // Enter '1' to '9' to make the next move. 
        fgets(send_buf, 1024, stdin);
        send(sockfd, send_buf, strlen(send_buf), 0);
        memset(send_buf, 0, sizeof(send_buf));

        // recv new map after you select
        recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
        printf("%s", recv_buf);
        memset(send_buf, 0, sizeof(send_buf));

        // wait opponent select 
        recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
        printf("%s", recv_buf);
         
        memset(recv_buf, 0, sizeof(recv_buf));
        }
       
 
        }    
    } else if ( strstr(recv_buf, "Enter the id of the user who you want to invite")!=NULL ) {

        fgets(send_buf, 1024, stdin);
        send(sockfd, send_buf, strlen(send_buf), 0);
        memset(send_buf, 0, sizeof(send_buf));
        memset(recv_buf, 0, sizeof(recv_buf));
        printf("Waiting for the answer from the opponent.\n");

        while (1) {
          // Enter the game
          recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
          printf("%s", recv_buf);

          // tutorial
          if ( strstr(recv_buf, "You can enter '1' - '9' to")!=NULL ) {
            memset(recv_buf, 0, sizeof(recv_buf));

          // waiting the accept or refuse message. 
          } else if (strstr(recv_buf, "Opponent Accepted")!=NULL) {
            memset(recv_buf, 0, sizeof(recv_buf));

          } else if (strstr(recv_buf, "Opponent refused")!=NULL ) {
            break;  

          } else if ( strstr(recv_buf, "You Lose" )!=NULL || strstr(recv_buf, "You have Win") !=NULL)   {  
              printf("\nGame is finished.\n\n");
              break;

          } else {
          memset(recv_buf, 0, sizeof(recv_buf));
          // Enter '1' to '9' to make the next move. 
          fgets(send_buf, 1024, stdin);
          send(sockfd, send_buf, strlen(send_buf), 0);
          memset(send_buf, 0, sizeof(send_buf));
          // recv the map after you select
          recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
          printf("%s", recv_buf);
          memset(recv_buf, 0, sizeof(recv_buf));
          // wait oppoent
          recv_len = recv(sockfd, recv_buf, sizeof(recv_buf), 0);
          printf("%s", recv_buf);
          }
           memset(recv_buf, 0, sizeof(recv_buf));
           memset(send_buf, 0, sizeof(send_buf));
        }

    } else if ( strstr(recv_buf, "Users are Online")!=NULL ) {
        memset(recv_buf, 0, sizeof(recv_buf));
        continue;
    } else if ( strstr(recv_buf, "You have logout.")!=NULL ) {
        close(sockfd);
        return 0;
    }
    
    memset(send_buf, 0, sizeof(send_buf));
    memset(recv_buf, 0, sizeof(recv_buf));
  }
   

  return 0;
}
