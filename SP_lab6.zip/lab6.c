#include <stdio.h>
#include "apue.h"
#include <sys/wait.h>

void accumulation(int d_sum);

int main()
{
	FILE* sum;
	int total_sum=0;
	pid_t pid[5];
	int year=5, week=52, day=7;

	sum = fopen("sum.txt", "w");
	fprintf(sum, "%d\n", 0);
	fclose(sum);

	/**********************************************************/
	TELL_WAIT();
	int i, pid2;
	for (i=0; i<5; ++i) {
	  if( (pid2= fork()) ==0) break;
	  pid[i] = pid2;
	}


	if (pid2>0) {

	int i2,i3;
	int range = 7*52;
	for (i2=0; i2<range; ++i2) 
	  for (i3=0; i3<5; ++i3) {
	    TELL_CHILD(pid[i3]);
	    WAIT_CHILD();
	  }
	}


	if (pid2==0) {	
	  int j;
	  for (j=1; j<=52; ++j) {
	  char filename1[10];
	  FILE *fp;
	    if (j>=10) {
	      sprintf(filename1, "%d-%d.txt", i+1, j);
	    } else {
	      sprintf(filename1, "%d-0%d.txt", i+1, j);
	    }
	    fp = fopen(filename1, "r");    
	    //printf("%s\t", filename1);   
	    int k,k2;
	    for (k2=0; k2<7; ++k2) {

	      int sum2 = 0;
	      for (k=0; k<96; ++k) {  
	        int tmp = 0;
	        fscanf(fp, "%d", &tmp);
	        sum2 = sum2 + tmp; 
	      }
	      WAIT_PARENT();
	      accumulation(sum2);
	      TELL_PARENT(getppid());
	    
	    }
	    fclose(fp);
	  }
	  exit(0);
	}

	/**********************************************************/
        
	sum = fopen("sum.txt", "r");
	fscanf(sum, "%d", &total_sum);
	printf("Day_Average = %d\n",total_sum/(year*week*day));
	fclose(sum);
	
	return 0;
}

void accumulation(int d_sum)    //Accumulating the daily sum to "sum.txt".
{
	FILE* sum;
	int tmp=0;

	sum = fopen("sum.txt", "r+");
	fscanf(sum, "%d", &tmp);

	tmp += d_sum;

	rewind(sum);
	fprintf(sum, "%d", tmp);
	fclose(sum);

	return;
}
